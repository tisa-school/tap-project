# Creeper electronics-case fit prototype

This revision adds a viewing opening for the micro:bit red LED display, an enlarged electronics bay and five smaller case parts for a Bambu P1S. It replaces the *design approach* of the original one-piece figurine; it is not a verified fitted enclosure.

## What was identified from the photo and official documentation

The photo appears to show an ELECFREAKS Smart AI Lens EF05045 and a Nezha EF05043 hub. The labels/revisions in the photo cannot be confirmed completely.

- Smart AI Lens: **35.96 mm wide, 60.90 mm total height including foot**, foot width **23.80 mm**. The cited drawing does not supply thickness or lens optical-centre dimensions.
- Nezha hub: **59.8 × 82.4 mm footprint**. The cited drawing does not supply height.
- micro:bit V2: **51.60 × 42.00 mm**, total component-depth envelope **11.65 mm**. Its information display is the red 5×5 LED matrix. Board revision in the photo is not confirmed.

Sources:

1. [ELECFREAKS AI Lens documentation and dimension drawing](https://github.com/elecfreaks/learn-en/blob/master/microbitplanetX/ai/Plant_X_EF05045.md)
2. [ELECFREAKS Nezha documentation and dimension drawing](https://github.com/elecfreaks/learn-en/blob/master/microbitExtensionModule/nezha.md)
3. [micro:bit Foundation mechanical specification](https://github.com/microbit-foundation/dev-docs/blob/main/hardware/2-0-revision.md#mechanical)

## Proposed electronics layout

Remove the original custom brick base/tower and rehouse the electronics. This case does **not** claim to slide over the original assembled LEGO robot.

The hub sits in the pedestal with its long dimension front-to-back. The micro:bit stays plugged into the hub and extends toward the rear viewing bay, red LEDs upward. The **56 × 38 mm opening is on the top rear of the pedestal, behind the character**. Check actual connector orientation and height before using this layout.

The camera sits in the head, with its lens facing the large front aperture. The wider opening allows positioning adjustment; lens field of view has not been verified. RJ11 wiring runs through the upright channel into the pedestal. Provide cable slack and confirm plugs fit before fixing components in place.

The internal bay is nominally **144 × 140 × 55 mm**. The display reference in the viewer is illustrative: a 35 mm hub height, 24 mm camera thickness, connector height and board positions are **assumptions**, not published dimensions. Component retention, seam fasteners and exact mounting brackets still need a physical fit check. The pieces can be temporarily held for a dry fit; permanent joining is not specified.

## Files and printing

1. **Hub-footprint-test.stl** — small ring: checks only the published hub footprint, with 0.5 mm clearance on each side. It does not check hub height, plugs or the complete robot. Print this first.
2. **Creeper-body_front.stl**
3. **Creeper-body_back.stl** — includes the viewing opening.
4. **Creeper-head_front.stl** — includes the camera aperture.
5. **Creeper-head_back.stl**
6. **Creeper-bottom.stl** — removable bottom tray.

Each case section is already rotated with its split face on the print bed. Import them as **separate objects**, one part per plate, in millimetres at 100% scale. The matching flat faces are assembly seams, not new exterior faces.

Use the P1S printer/nozzle/filament profile. Enable suitable supports (for example Tree auto) and inspect the slice, including internal roofs and heart accessories. Remove supports while the halves are still open. A connected mesh can still have unsupported regions in a layer-by-layer print. Do not treat the connected-mesh check as a support check.

The original one-piece file is approximately 290 mm tall; P1S build height is 256 mm. Do not print or uniformly shrink that original file to fit the printer if fitting electronics is the goal.

## Checks and limits

The five revised case sections are closed, connected meshes, rest on the print bed and fit a 256 × 256 × 256 mm build envelope. A vertical line-of-sight test is clear above the **assumed** red-LED location. The illustrative hardware envelopes do not collide with the case.

These files have **not** been sliced in Bambu Studio, printed, or fitted to the real hardware. Supports, seam retention, tolerances, component mounting, lens alignment/field of view, hub height and exact connector positions still need validation. The custom brick assembly dimensions cannot be obtained from the standard component drawings or this single photo.

`Creeper-case.scad` is the editable source and imports `Creeper-reference.stl`; keep them together. `hardware-dimensions.json` separates published values from unknowns. `hardware-preview.scad` contains the explicitly assumed reference envelopes. `Creeper-case-preview.html` is an offline browser viewer, not live hardware data.
