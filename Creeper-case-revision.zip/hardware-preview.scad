// VISUAL FIT REFERENCES ONLY. Hub height, lens thickness and connector positions are assumptions.
part="all"; // all, hub, camera, microbit
module hub(){translate([-29.9,-49.4,5])cube([59.8,82.4,35]);} // 35 mm HEIGHT ASSUMED
module camera(){
 translate([-17.98,-50,185.0])cube([35.96,24,35.90]); // 24 mm THICKNESS ASSUMED
 translate([-6,-50,169])cube([12,24,17]);
 translate([-11.90,-50,160])cube([23.80,24,10]);
}
module microbit(){translate([-25.8,33,40])cube([51.6,42,1.6]);} // connector height/position ASSUMED
if(part=="hub")hub();else if(part=="camera")camera();else if(part=="microbit")microbit();else {hub();camera();microbit();}
