// FUNCTIONAL FIT PROTOTYPE. Units mm. NOT print-tested or fitted to the real robot.
// Manufacturer confirmed: EF05045 lens 35.96 W x 60.90 H incl. foot (23.80 W).
// Nezha EF05043 hub footprint 59.8 W x 82.4 L. Its HEIGHT is not documented here.
// micro:bit V2: 51.60 W x 42.00 H, 11.65 total component-depth envelope.
// Layout: electronics rehoused; no fit claim for the original custom LEGO tower/base.
part="assembly"; // body_front, body_back, head_front, head_back, bottom, assembly
print_orientation=true;
seam_y=-35;
neck_z=155;
// Full-board viewing bay behind the figure. The connector-side edge is kept covered.
led_window_width=56;
led_window_depth=38;
led_window_y=59;
// Oversized camera aperture pending the manufacturer's missing lens-centre measurement.
camera_window_width=40;
camera_window_height=56;
camera_window_z=196;
$fn=28;
module rounded_xy(s,r){linear_extrude(height=s[2])offset(r=r)translate([r,r])square([s[0]-2*r,s[1]-2*r]);}
module electronics_shell(){
 difference(){
  union(){
   // Preserve the character above its old pedestal.
   intersection(){import("Creeper-reference.stl");translate([-150,-150,50])cube([300,300,300]);}
   // Larger bay: 144 x 140 x 55 mm clear volume before connector openings.
   translate([-84,-69,0])rounded_xy([168,153,60],12);
   translate([-87,-72,55])rounded_xy([174,159,5],12);
  }
  translate([-72,-60,-1])cube([144,140,56]);
  // Reconnect hub wiring to the existing upright passage.
  translate([-9,-47,43])cube([18,16,130]);
  // Micro:bit LED/board viewing opening in the rear top deck, clear of the figure.
  translate([-led_window_width/2,led_window_y-led_window_depth/2,45])cube([led_window_width,led_window_depth,45]);
  // Charging, power and RJ11 cable access at the rear, to be aligned after a fit check.
  translate([-24,77,7])cube([48,15,28]);
  // Broad camera opening provides adjustment, rather than assuming an optical centre.
  translate([-camera_window_width/2,-85,camera_window_z-camera_window_height/2])cube([camera_window_width,55,camera_window_height]);
 }
}
module segment(front=true,head=false){
 intersection(){
  electronics_shell();
  translate([-150,front?-150:seam_y,head?neck_z:-1])cube([300,front?150+seam_y:150-seam_y,head?170:neck_z+1]);
 }
}
module oriented(front,head){
 if(print_orientation)rotate([front?-90:90,0,0])translate([0,-seam_y,-(head?222.5:77.5)])segment(front,head);
 else segment(front,head);
}
module bottom(){
 translate([-84,-69,-2.4])rounded_xy([168,153,2.4],12);
 difference(){
  translate([-71.6,-59.6,-.1])rounded_xy([143.2,139.2,3.1],1);
  translate([-70,-58,-.2])rounded_xy([140,136,3.4],1);
 }
}
if(part=="body_front")oriented(true,false);
else if(part=="body_back")oriented(false,false);
else if(part=="head_front")oriented(true,true);
else if(part=="head_back")oriented(false,true);
else if(part=="bottom")translate([0,0,2.4])bottom();
else {electronics_shell();bottom();}
