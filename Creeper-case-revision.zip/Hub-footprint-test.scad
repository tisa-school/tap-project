// Nezha EF05043 footprint gauge ONLY: not a hub-height or whole-robot fit test.
// Published footprint 59.8 x 82.4; add 0.5 mm clearance per side.
difference(){cube([64.8,87.4,4]);translate([2,2,-1])cube([60.8,83.4,6]);}
