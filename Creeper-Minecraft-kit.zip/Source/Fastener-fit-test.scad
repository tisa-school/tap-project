// Optional print-first coupon. Not a case component.
difference(){cube([28,18,5]);translate([7,9,-1])cylinder(d=3.4,h=8,$fn=32);translate([7,9,2.3])cylinder(d=6.8,h=4,$fn=6);translate([21,9,-1])cylinder(d=1.6,h=8,$fn=24);}
