// FULL-FACE CREEPER FIT PROTOTYPE. mm. Unverified hub/camera thickness and connector positions.
part="assembly"; print_orientation=true; $fn=32;
module roundxy(s,r=2){linear_extrude(height=s[2])offset(r=r)translate([r,r])square([s[0]-2*r,s[1]-2*r]);}
module post(x,z,d=9.2){translate([x,.05,z])rotate([-90,0,0])cylinder(d=d,h=22.95);}
module bolt(x,z){
 translate([x,-24,z])rotate([-90,0,0])cylinder(d=3.4,h=49);
 translate([x,-23.01,z])rotate([-90,0,0])cylinder(d1=6.4,d2=3.4,h=1.5);
 translate([x,3,z])rotate([-90,0,0])cylinder(d=6.8,h=21,$fn=6);
}
module hardware_features(){
 for(x=[-23,23])post(x,5);
 for(x=[-32,32])post(x,216);
 // The small body fastener bosses remain within the existing 103 mm outer envelope.
 for(x=[-36,36])translate([x,-23,82])rotate([-90,0,0])cylinder(d=10,h=46);
 for(x=[-32,32])translate([x-5,15,135])cube([10,8,11]);
 for(x=[-20,20])for(y=[-10,10])translate([x-4,y-3,12.4])cube([8,6,1.1]);
 // Camera-pad edge seats at Z=143, with tie channels under the pad.
 for(side=[-1,1])scale([side,1,1]){
  translate([13.1,-16,142.4])cube([2.4,32,.6]);
  translate([35.5,-16,142.4])cube([3.1,32,.6]);
 }
}
module case(){difference(){
 union(){import("approved-face-reference.stl");hardware_features();}
 for(x=[-23,23])bolt(x,5);
 for(x=[-36,36])bolt(x,82);
 for(x=[-32,32])bolt(x,216);
 for(x=[-32,32]){
  translate([x,19.5,134])cylinder(d=3.4,h=20);
  translate([x,19.5,134.9])cylinder(d=6.4,h=2.6);
  translate([x,19.5,146])cylinder(d=6.8,h=4,$fn=6);
 }
 // Allow the camera pads to seat beside the neck fasteners without interference.
 for(x=[-38.2,13.2])translate([x,15,142.8])cube([25,1.3,2.9]);
 // Keep the camera pad seats outside the pad clearance cut.
 for(side=[-1,1])scale([side,1,1]){
  translate([39.8,-21,162])cube([3,42,54]);
  for(z=[166,211])translate([37.7,0,z])rotate([0,90,0])cylinder(d=1.6,h=6);
 }
 // Rear tie slots for the upright hub, selectable around clear areas.
 for(x=[-20,20])for(z=[23,66])translate([x-4,19,z])cube([8,8,20]);
 translate([-12,19,40])cube([24,8,12]);
}}
module segment(front=true,head=false){intersection(){case();translate([-100,front?-60:0,head?139.5:-1])cube([200,60,head?100:140.5]);}}
module cover(){difference(){
 translate([39.8,-20.8,162.2])cube([1.2,41.6,53.6]);
 for(z=[166,211])translate([38,0,z])rotate([0,90,0])cylinder(d=2.3,h=5);
}}
module pad(){difference(){
 translate([-12.2,-16,0])roundxy([24.4,32,2.5],1);
 for(x=[-6,6]){
  for(y=[-14,14])translate([x-1.8,y-1.5,-1])cube([3.6,3,5]);
  translate([x-1.8,-17,-.1])cube([3.6,34,1.1]);
 }
}}
module oriented(front,head){if(print_orientation)rotate([front?-90:90,0,0])translate([0,0,-(head?181:70)])segment(front,head);else segment(front,head);}
if(part=="body_front")oriented(true,false);
else if(part=="body_back")oriented(false,false);
else if(part=="head_front")oriented(true,true);
else if(part=="head_back")oriented(false,true);
else if(part=="camera_pad")pad();
else if(part=="port_cover"){if(print_orientation)rotate([0,-90,0])translate([-39.8,0,-189])cover();else cover();}
else case();
