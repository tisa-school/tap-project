// FRONT DISPLAY / REVERSIBLE SIDE CAMERA - FIT PROTOTYPE, NOT PRINT-TESTED.
// Hardware fit, hub thickness, connector positions and camera thickness remain provisional.
// Units mm. M3 clearance 3.4 mm; nut channels sized for standard 5.5 mm AF M3 nuts.
part="assembly";
print_orientation=true;
seam_y=-35;
neck_z=155;
$fn=32;
module rounded_xy(s,r=3){linear_extrude(height=s[2])offset(r=r)translate([r,r])square([s[0]-2*r,s[1]-2*r]);}
module screw_y(x,z,d=3.4){translate([x,-46,z])rotate([-90,0,0])cylinder(d=d,h=22);}
module screw_z(x,y,z0,h,d=3.4){translate([x,y,z0])cylinder(d=d,h=h);}
module seam_tabs(){
 for(x=[-70,70])translate([x-7,-42,238])rounded_xy([14,14,12],2);
 for(x=[-88,88])translate([x-8,-42,19])rounded_xy([16,14,12],2);
 for(x=[-57,57])translate([x-7,-42,138])rounded_xy([14,14,12],2);
}
module neck_tabs(){
 for(side=[-1,1])translate([side<0?-80:50,5,148])rounded_xy([30,14,14],2);
}
module bottom_tabs(){
 for(x=[-90,90])for(y=[-48,48])translate([x<0?-98:78,y-8,0])rounded_xy([20,16,12],3);
}
module cap_bores(){
 for(y=[-28,28]){
  // Right cap: screw access from outside, hex nut inserted from the open inside face.
  translate([33,y,212])rotate([0,90,0])cylinder(d=6.8,h=27.5,$fn=6);
  translate([59,y,212])rotate([0,90,0])cylinder(d=3.4,h=15);
  // Left cap, symmetric.
  translate([-60.5,y,212])rotate([0,90,0])cylinder(d=6.8,h=27.5,$fn=6);
  translate([-74,y,212])rotate([0,90,0])cylinder(d=3.4,h=15);
 }
}
module assembled_case(){
 difference(){
  union(){import("approved-shell-reference.stl");seam_tabs();neck_tabs();bottom_tabs();translate([-44,-55,56])rounded_xy([88,10,18],3);}
  // Clearance for the upright hub cradle backplate.
  translate([-50,-52,45])cube([100,44,51]);
  for(x=[-70,70])screw_y(x,244);
  for(x=[-88,88])screw_y(x,25);
  for(x=[-57,57])screw_y(x,144);
  for(x=[-73,73])screw_z(x,12,145,22);
  for(x=[-90,90])for(y=[-48,48])screw_z(x,y,-2,17);
  cap_bores();
  // Both head pockets accept the same reversible camera cradle.
  for(x=[-48,48])for(y=[-16,16]){
   screw_z(x,y,154.9,20);
   screw_z(x,y,154.9,3.1,6.4); // recessed underside screw head, clear of the neck seam
  }
 }
}
module case_segment(front=true,head=false){
 intersection(){assembled_case();translate([-150,front?-150:seam_y,head?neck_z:-1])cube([300,front?150+seam_y:150-seam_y,head?160:neck_z+1]);}
}
module bottom(){
 difference(){
  union(){
   translate([-84,-69,-5])rounded_xy([168,153,5],12);
   for(x=[-90,90])for(y=[-48,48])translate([x<0?-98:78,y-8,-5])rounded_xy([20,16,5],3);
   difference(){
    translate([-71.6,-59.6,-.1])rounded_xy([143.2,139.2,3.1],1);
    translate([-70,-58,-.2])rounded_xy([140,136,3.4],1);
   }
  }
  for(x=[-90,90])for(y=[-48,48]){screw_z(x,y,-6,10);screw_z(x,y,-5.1,3.1,6.4);}
  for(x=[-37,37]){screw_z(x,-30,-6,12);screw_z(x,-30,-5.1,3.1,6.4);}
 }
}
module camera_cover(){
 difference(){
  translate([-70,0,212])rotate([0,90,0])linear_extrude(height=4)offset(r=4)square([40,56],center=true);
  for(y=[-28,28])translate([-72,y,212])rotate([0,90,0])cylinder(d=3.4,h=10);
 }
}
module hub_cradle(){
 difference(){
  union(){
   translate([-42,-52,0])rounded_xy([84,42,5],3);
   translate([-33,-14,4])cube([66,4,84]);
  }
  for(x=[-37,37])screw_z(x,-30,-1,9);
  // Long slots let two 10 mm hook-and-loop straps be positioned around clear areas.
  for(x=[-25,6])translate([x,-16,14])cube([19,8,58]);
 }
}
// Canonical camera cradle: same printed part, rotated 180 degrees in plan for the other side.
module camera_cradle(){
 difference(){
  union(){translate([-17.5,-20.5,0])rounded_xy([35,41,2],1);
   translate([13,-20.5,1.5])cube([4,41,60.5]);}
  for(y=[-16,16])screw_z(-3,y,-1,6);
  // Lower two slots accept small cable ties around the mounting foot, clear of the lens.
  for(z=[4,12,30,51])translate([11,-15,z])cube([8,30,4]);
 }
}
module oriented_segment(front,head){
 if(print_orientation)rotate([front?-90:90,0,0])translate([0,-seam_y,-(head?211:77.5)])case_segment(front,head);
 else case_segment(front,head);
}
if(part=="body_front")oriented_segment(true,false);
else if(part=="body_back")oriented_segment(false,false);
else if(part=="head_front")oriented_segment(true,true);
else if(part=="head_back")oriented_segment(false,true);
else if(part=="bottom") {if(print_orientation)translate([0,0,5])bottom();else bottom();}
else if(part=="camera_cover") {if(print_orientation)rotate([0,-90,0])translate([70,0,-212])camera_cover();else camera_cover();}
else if(part=="hub_cradle") {if(print_orientation)rotate([-90,0,0])translate([0,10,-44])hub_cradle();else hub_cradle();}
else if(part=="camera_cradle")camera_cradle();
else {assembled_case();bottom();hub_cradle();translate([-45,0,168])camera_cradle();}
