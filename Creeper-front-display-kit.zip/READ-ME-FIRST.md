# Front-display Creeper: print parts and assembly guide

**FIT PROTOTYPE — not print-tested or fitted to the real electronics.** The red micro:bit LED display faces forward, the camera can be moved between the two head sides, and all hearts have been removed. This case replaces the original custom brick base/tower.

Start with `Assembly-instructions.pdf` and `01-print-parts.png`. The seven-page PDF contains the hardware list and six illustrated assembly stages. `02-assembly-instructions.png` is a single-sheet overview.

## Printed pieces

Print one of each numbered file in `STL/`:

01. Body front
02. Body back
03. Head front
04. Head back
05. Bottom tray
06. Unused camera-port cover
07. Upright hub holder
08. Reversible camera holder

The eight numbered STLs are already oriented for printing, in millimetres. Keep 100% scale. All fit within the P1S 256 × 256 × 256 mm build envelope; the widest piece is 196 mm. The files in `Source/` are references/editable geometry, **not additional pieces to slice**. The cover and camera holder are interchangeable between sides: rotate the camera holder 180° around its vertical axis for the other side, and move the cover to the unused port.

An optional `00_optional_hub_outline_test.stl` checks the hub's published 59.8 × 82.4 mm footprint with 0.5 mm clearance per side. It does not check hub thickness, connectors, or the whole assembly. Print the holder/test pieces and check hardware before spending time and filament on the large shells.

## Hardware to supply (not printed)

- 16 × M3 × 20 mm machine screws.
- 2 × M3 × 12 mm machine screws.
- 18 × standard M3 hex nuts, about 5.5 mm across flats.
- 2 × 10 mm-wide hook-and-loop straps, approximately 250 mm long.
- 2 × small cable ties, at most 3.5 mm wide, approximately 150 mm long.
- Your existing compatible hub-to-camera cable.

Fastener count by operation:

| Operation | Screws | Nuts |
|---|---|---|
| Hub holder to tray | 2 × M3×12 | 2 |
| Camera holder to head | 2 × M3×20 | 2 |
| Unused camera-port cover | 2 × M3×20 | 2 |
| Head front/back seam | 2 × M3×20 | 2 |
| Body front/back seam | 4 × M3×20 | 4 |
| Head-to-body joint | 2 × M3×20 | 2 |
| Tray to case | 4 × M3×20 | 4 |

The camera-cover nuts go into the hexagonal channels from the open inside of the head. The camera-holder screw heads seat in recesses under the head floor; install these before the head is joined to the body. Other nuts are accessible on the external joining tabs. Bottom screw heads are recessed into the tray.

## Printing

Use the P1S profile matching your actual nozzle and filament. A 0.4 mm nozzle and 0.20 mm layers are a reasonable starting point, not a validated profile. Print one large case section per plate. Inspect Bambu Studio's layer preview and enable appropriate supports, such as Tree auto, where indicated. In particular, inspect projecting tabs, inside roofs and the holder slots. Remove supports with the shells still open, then check the mating surfaces and bolt holes. Mesh connectivity is not a support check.

No printer-specific G-code is supplied. These parts have not been sliced in Bambu Studio or physically printed. Do not ignore a floating-region or unsupported-feature warning; inspect it in the slicer. If tolerances or joint seating are poor, correct them during the dry fit rather than forcing or gluing the assembly.

## Layout and known dimensions

The proposed layout puts the Nezha hub upright in the body, still connected to the micro:bit, with all 25 red LEDs facing the front window. The camera mounts on its foot inside one head pocket, held by the printed cradle and small cable ties; keep ties clear of the lens. Its cable runs through the open neck to an IIC sensor port on the hub. Select clear positions for the hub straps, away from connectors and controls.

The photo appears to show ELECFREAKS Smart AI Lens EF05045 and Nezha EF05043; the revision labels are not confirmed. Published dimensions:

- [ELECFREAKS EF05045](https://github.com/elecfreaks/learn-en/blob/master/microbitplanetX/ai/Plant_X_EF05045.md): 35.96 mm wide × 60.90 mm total height including foot; foot width 23.80 mm. Thickness and optical-centre position were not provided by the cited drawing.
- [ELECFREAKS Nezha EF05043](https://github.com/elecfreaks/learn-en/blob/master/microbitExtensionModule/nezha.md): 59.8 × 82.4 mm footprint; thickness/height was not provided by the cited drawing.
- [micro:bit Foundation V2](https://github.com/microbit-foundation/dev-docs/blob/main/hardware/2-0-revision.md#mechanical): 51.60 × 42.00 mm and an 11.65 mm component-depth envelope. The board revision in the photo is not confirmed.

**The hardware illustrations use an assumed 35 mm hub thickness, 24 mm camera thickness and provisional connector positions.** The cradle position and front window depend on the real connector layout. The case permits roughly 38 mm between the hub backrest and the front internal wall; if the actual unit or its connectors are larger, the source must be adjusted. Actual lens position, field of view, switches, cable clearance, fastener access under real plugs and mounting tolerances still need a physical check. Do not describe the illustrations as measured CAD models of the electronics.

## What was checked

- All eight assembled-part meshes have closed edges and one connected component.
- The supplied print orientations rest on the bed and fit the P1S build envelope.
- The holders, cover, tray and illustrative electronics envelopes have no positive-volume collision with the case. Seating faces touch as intended.
- The PDF has seven pages and contains all six assembly stages; the diagrams were rendered from the actual part meshes.

These checks do not establish support-free printing, structural strength, actual electronics fit or electrical/camera operation. Power off/unplug for installation; test display visibility, A/B button access, camera operation, power/charging access and cable routing before final tightening.
